﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace CoreLibrary
{

    [ExcludeFromCodeCoverage]
    public class Logininfo
    {
        public int roleid { get; set; }
        public int userid { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class LoginModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
       
    }
    [ExcludeFromCodeCoverage]
    public class TokenResponseObj
    {
        public string token { get; set; }
        public DateTime expiration { get; set; }
    }
    public class GenericResponseObject<T>
    {
        public string message { get; set; }

        public T data { get; set; }
    }



}
