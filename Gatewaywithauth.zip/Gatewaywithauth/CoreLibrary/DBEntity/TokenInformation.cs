﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace CoreLibrary
{
    public class TokenInformation
    {
        [Key]
        [JsonIgnore]
        public int TokenInformationID { get; set; }

        public int UserId { get; set; }

        public int RoleId { get; set; }
        public string Token { get; set; }

        public DateTime Validto { get; set; }

    }

    [ExcludeFromCodeCoverage]
    public class UserMaster
    {
        [Key]
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public bool Active { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreateDate{ get; set; }
    public int ModifyBy { get; set; }

        public DateTime ModifyDate { get; set; }
        public int RoleId { get; set; }

    }
}
