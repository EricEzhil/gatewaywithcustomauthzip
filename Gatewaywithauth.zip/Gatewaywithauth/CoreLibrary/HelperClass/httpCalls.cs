﻿using Newtonsoft.Json;

using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CoreLibrary
{
    public class HttpCalls
    {

        public async Task<string> HttpGetJsonString(string URL,string token=null)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    if (!string.IsNullOrEmpty(token))
                    {
                       client.DefaultRequestHeaders.Add("authToken", token);
                    }

                    var response = await client.GetAsync(URL);
                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content.ReadAsStringAsync();

                    }
                }
            }
            catch (Exception EX)
            {

                //Log.Error("Exception Occured in HTTP CALLS", EX);
                throw;
            }

            return null;
        }

        public async void HttpPostCall(string json, string URL)
        {

            try
            {
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                using (HttpClient client = new HttpClient())
                {
                    //Add role to go through custom authorize 
                    client.DefaultRequestHeaders.Add("oRoleId", "1");//1 for all access
                    var response = await client.PostAsync(URL, data);
                    using (HttpContent content = response.Content)
                    {
                        string result = content.ReadAsStringAsync().Result;
                        // return JsonObject.Parse(result);

                    }
                }
            }
            catch (Exception EX)
            {

                //Log.Error("Exception Occured in HTTP CALLS", EX);
                throw;
            }

        }

        public async Task<bool> HttpDeleteCall(string URL)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    //UpdateToken(client);
                    var response = await client.DeleteAsync(URL);
                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception EX)
            {

              //  Log.Error("Exception Occured in HTTP CALLS", EX);
                throw;
            }


        }

        




        public async Task<object> HttpGetObj<AnyType>(string URL)
        {
            try
            {
                var x = await HttpGetJsonString(URL);
                return JsonConvert.DeserializeObject<AnyType>(x);
            }
            catch (Exception EX)
            {

                //Log.Error("Exception Occured in HTTP CALLS", EX);
                throw;
            }


        }
        public async Task<object> HttpGetObj<AnyType>(string URL, string token)
        {
            try
            {
                var x = await HttpGetJsonString(URL, token);
                return JsonConvert.DeserializeObject<AnyType>(x);
            }
            catch (Exception EX)
            {

                //Log.Error("Exception Occured in HTTP CALLS", EX);
                throw;
            }


        }



    }
}
