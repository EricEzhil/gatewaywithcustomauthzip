﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace CoreLibrary
{
    public class AuthenticationHelper
    {
        IConfiguration config;
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        public AuthenticationHelper(IConfiguration _config)
        {
            config = _config;
        }

        public TokenResponseObj GenerateKey(string username)
        {


            var jwtconfig = config.GetSection("JwtConfig");
            var signingKey = jwtconfig["Secret"];
            var authClaims = new[]
              {
                    new Claim(JwtRegisteredClaimNames.Sub, username),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                };

            var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey));

            var token = new JwtSecurityToken(
                issuer: jwtconfig["Iss"],
                audience: jwtconfig["Aud"],
                expires: DateTime.Now.AddHours(12),
                claims: authClaims,
                signingCredentials: new Microsoft.IdentityModel.Tokens.SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                );

            var result = new TokenResponseObj
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                expiration = token.ValidTo
            };


            return result;
        }


    }


}
