﻿namespace CoreLibrary
{
    public interface IAuthService
    {
        TokenInformation ValidateToken(string token);

        object AuthenticateUser(LoginModel loginModel);
      
        bool RemoveTokenInfo(Logininfo userMaster);

    }
    public interface IAuthRepository
    {
        TokenInformation GetTokenInfo(string token);
        bool SaveTokenInfo(TokenInformation token);

        bool RefreshTokenInfo(TokenInformation token);

        int RemoveTokenInfo(Logininfo userMaster);
    }
}
