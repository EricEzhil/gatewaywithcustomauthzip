﻿using System.Collections.Generic;
using System.Threading.Tasks;
namespace CoreLibrary
{
    public interface IUserMasterService
    {

        int RegisterUser(UserMaster userMaster, Logininfo logininfo);
        UserMaster GetUser(int userid);

       
        UserMaster Getuserwithusername(string Username);
        string DeactivateUser(int userid, Logininfo logininfo);
       
        
    }
    public interface IUserMasterRepository
    {

        int RegisterUser(UserMaster userMaster);
        Task<UserMaster> ValidateLogin(string Username, string password);
        
        UserMaster GetUser(int userid);
        Task<UserMaster> Getuserwithusername(string Username);
        UserMaster DeactivateUser(int userid);
        
       

    }
}
