﻿using CoreLibrary;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Ocelot.Middleware;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gatewaywithauth
{
    public class GatewayHelper
    {
        private IConfiguration configuration;
        HttpCalls httpCalls;
        IConfigurationSection _urls;
        public GatewayHelper(IConfiguration configuration)
        {
            this.configuration = configuration;
            _urls = this.configuration.GetSection("OtherApiUrls");
        }

        public bool ExtendToken(string token)
        {
            httpCalls = new HttpCalls();
            string AuthApi = _urls["AuthApi"].ToString(); 
            var res =  (TokenInformation)httpCalls.HttpGetObj<TokenInformation>(AuthApi, token).Result;
            if (res != null && res.UserId > 0) return true;

            return false;
            
        }
        public string GenerateUnauthError(DownstreamContext context)
        {
            context.HttpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
            context.HttpContext.Response.ContentType = "application/json; charset=utf-8";
            var message = "Authentication Failed";
            var result = JsonConvert.SerializeObject(new { message });
            return result;
        }
    }
}
