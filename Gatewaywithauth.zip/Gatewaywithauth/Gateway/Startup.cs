using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Ocelot.DependencyInjection;
using Ocelot.Middleware;

namespace Gatewaywithauth
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
         
            var jwtconfig = Configuration.GetSection("JwtConfig");
            var signingKey = jwtconfig["Secret"];
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.SaveToken = true;
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidAudience = jwtconfig["Iss"],
                    ValidIssuer = jwtconfig["Aud"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey))
                };
                options.Events = new JwtBearerEvents()
                {
                    OnAuthenticationFailed = context =>
                    {
                        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                        context.Response.ContentType = "application/json; charset=utf-8";
                        var message = "Token Not provided for authentication or is Invalid";
                        var result = JsonConvert.SerializeObject(new { message });
                        return context.Response.WriteAsync(result);
                    }
                };
            });

          

            services.AddOcelot();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public async void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            Microsoft.Extensions.Primitives.StringValues authTokens;
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            var configuration = new OcelotPipelineConfiguration
            {
                PreAuthenticationMiddleware = async (ctx, next) =>
                {
                    if (ctx.DownstreamReRoute.AuthenticationOptions.AuthenticationProviderKey != null)
                    {
                        GatewayHelper helper = new GatewayHelper(Configuration);
                        ctx.HttpContext.Request.Headers.TryGetValue("Authorization", out authTokens);
                        var _token = authTokens.FirstOrDefault();
                        if (string.IsNullOrEmpty(_token))
                        {
                            await ctx.HttpContext.Response.WriteAsync(helper.GenerateUnauthError(ctx));
                        }
                        else
                            await next.Invoke();
                    }
                    else
                        await next.Invoke();
                },
                PreQueryStringBuilderMiddleware = async (ctx, next) =>
                {
                    if (ctx.DownstreamReRoute.AuthenticationOptions.AuthenticationProviderKey != null)
                    {
                        GatewayHelper helper = new GatewayHelper(Configuration);
                        ctx.HttpContext.Request.Headers.TryGetValue("Authorization", out authTokens);
                        var _token = authTokens.FirstOrDefault();
                        if (!string.IsNullOrEmpty(_token))
                        {
                            if (helper.ExtendToken(_token.Replace("Bearer ", "")))
                            {
                                //ctx.DownstreamRequest.Headers.Add();//can add any headers to downstream request 
                                await next.Invoke();
                            }
                            else
                            {
                                await ctx.HttpContext.Response.WriteAsync(helper.GenerateUnauthError(ctx));
                            }
                        }
                        else
                        {
                            await ctx.HttpContext.Response.WriteAsync(helper.GenerateUnauthError(ctx));
                        }
                    }
                    else
                        await next.Invoke();
                }
            };
            await app.UseOcelot(configuration);
        }
    }
}
