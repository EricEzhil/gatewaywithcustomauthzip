﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CoreLibrary;

namespace UserApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserMasterController : ControllerBase
    {
        public readonly IUserMasterService _usermasterservice;
        
        public UserMasterController(IUserMasterService usermasterservice)
        {
            _usermasterservice = usermasterservice;

        }
        [HttpPost("Register")]
        public GenericResponseObject<UserMaster> RegisterUser(UserMaster userMaster)
        {
            GenericResponseObject<UserMaster> obj = new GenericResponseObject<UserMaster>();
            try
            {
                if (_usermasterservice.RegisterUser(userMaster, GetUserInfo()) > 0) obj.message = "User Saved";
                else obj.message = "Not saved";
            }
            catch (Exception)
            {
                obj.message = "An Exception Has occured";
            }

            return obj;

        }

        
        [HttpGet]
        public GenericResponseObject<UserMaster> GetUser(int userid)
        {
            GenericResponseObject<UserMaster> obj = new GenericResponseObject<UserMaster>() { message = "No Data To List" };
            try
            {
                var pat = _usermasterservice.GetUser(userid);
                if (pat != null)
                {
                    pat.Password = null;
                    obj.message = "SucessFull";
                    obj.data = pat;
                }
            }
            catch (Exception)
            {
                obj.message = "An Exception Has occured";
            }
            return obj;

        }
              
        
        [HttpPut]
        public string DeactivateUser(int userid)
        {
            try
            {
                return _usermasterservice.DeactivateUser(userid, GetUserInfo());
            }
            catch (Exception)
            {
                return "An Exception Has occured";
            }

        }
        [HttpGet("GetUserbyusername")]
        public GenericResponseObject<UserMaster> GetUserbyusername(string username)
        {
            GenericResponseObject<UserMaster> obj = new GenericResponseObject<UserMaster>() { message = "No Data " };
            try
            {
                var pat = _usermasterservice.Getuserwithusername(username);
                if (pat != null)
                {

                    obj.message = "Sucessfull";
                    obj.data = pat;
                }

            }
            catch (Exception)
            {
                obj.message = "An Exception Has occured";
            }
            return obj;
        }

        private Logininfo GetUserInfo()
        {
           //get login info from claims in actual implementation
            return new Logininfo() { roleid = 1, userid = 1 };
          
        }
    }
}
