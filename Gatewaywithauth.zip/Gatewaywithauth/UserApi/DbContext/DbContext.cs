﻿using CoreLibrary;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;
namespace UserApi
{
    [ExcludeFromCodeCoverage]
    public class UserMasterContext : DbContext
    {
        public UserMasterContext(DbContextOptions<UserMasterContext> options) : base(options)
        {

        }
        public DbSet<UserMaster> UserMaster { get; set; }
      
      
    }
}
