﻿
using CoreLibrary;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace UserApi
{
    public class UserMasterService : IUserMasterService
    {
        private readonly IUserMasterRepository _usermasterrepository;
        private IConfiguration _config;
        HttpCalls httpCalls;
        IConfigurationSection urls;

        public UserMasterService(IUserMasterRepository usermasterrepository, IConfiguration config)
        {
            _usermasterrepository = usermasterrepository;
            _config = config;
            urls = _config.GetSection("OtherApiUrls");
        }

      

        private byte[] GetBytes(string img)
        {
            try
            {
                return Convert.FromBase64String(img);
            }
            catch (Exception ex)
            {
                //Log.Error("Exception in Get Bytes");
                return null;
            }

        }
        public int RegisterUser(UserMaster userMaster, Logininfo logininfo)
        {
            var encpwd = EncryptionHelper.Encrypt(userMaster.Password);
            userMaster.Password = encpwd;
            userMaster.CreateDate = DateTime.Now;
            userMaster.CreatedBy = logininfo == null ? 0 : logininfo.userid;
            userMaster.Active = true;
            return _usermasterrepository.RegisterUser(userMaster);
        }
       


        public string DeactivateUser(int userid, Logininfo logininfo)
        {
            var user = _usermasterrepository.DeactivateUser(userid);
            if (user != null)
            {
                RemoveToken(new Logininfo() { roleid = user.RoleId, userid = user.UserId });
                return "Updated";
            }
            return "Not Updated";

        }

        public UserMaster GetUser(int userid)
        {
            return _usermasterrepository.GetUser(userid);
        }





        public Task<UserMaster> ValidateLogin(string Username, string password)
        {
            return _usermasterrepository.ValidateLogin(Username, password);
        }

        public UserMaster Getuserwithusername(string Username)
        {
            return _usermasterrepository.Getuserwithusername(Username).Result;
        }

      


        public void RemoveToken(Logininfo token)
        {
            httpCalls = new HttpCalls();
            string AuthApi = urls["AuthApi"].ToString() + "/RemoveTokenInfo"; //
            var json = JsonConvert.SerializeObject(token);
            httpCalls.HttpPostCall(json, AuthApi);
        }

      
    }
}
