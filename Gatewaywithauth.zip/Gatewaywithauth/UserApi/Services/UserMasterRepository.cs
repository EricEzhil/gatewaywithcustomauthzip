﻿using CoreLibrary;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserApi
{
    public class UserMasterRepository : IUserMasterRepository
    {
        private readonly UserMasterContext _Dbcontext;


        public UserMasterRepository(UserMasterContext dbcontext)
        {
            _Dbcontext = dbcontext;
        }

       


        public UserMaster GetUser(int userid)
        {
            try
            {
                var resuserMaster = _Dbcontext.UserMaster.AsNoTracking().FirstOrDefault(x => x.UserId == userid);
                return resuserMaster;
            }
            catch (Exception ex)
            {
                //Log.Error("Exception in UserMasterRepository", ex);
                throw ex;
            }
        }

        public int RegisterUser(UserMaster userMaster)
        {
            try
            {
                var resuserMaster = _Dbcontext.UserMaster.AsNoTracking().FirstOrDefault(x => x.UserId == userMaster.UserId);
                if (resuserMaster == null)
                {
                    _Dbcontext.UserMaster.Add(userMaster);
                    _Dbcontext.SaveChanges();
                }
                else
                {
                    _Dbcontext.UserMaster.UpdateRange(userMaster);
                    _Dbcontext.SaveChanges();
                }
                return userMaster.UserId;
            }
            catch (Exception ex)
            {
                //Log.Error("Exception in UserMasterRepository", ex);
                throw ex;
            }
        }

       

        public int changepassword(UserMaster usermaster)
        {

            var resuserMaster = _Dbcontext.UserMaster.AsNoTracking().FirstOrDefault(x => x.UserId == usermaster.UserId);
            resuserMaster.ModifyBy = usermaster.ModifyBy;
            resuserMaster.ModifyDate = usermaster.ModifyDate;
            resuserMaster.Password = usermaster.Password;
            _Dbcontext.UserMaster.UpdateRange(resuserMaster);
            return _Dbcontext.SaveChanges();

        }


        public async Task<UserMaster> ValidateLogin(string Username, string password)
        {
            try
            {
                var usermaster = await _Dbcontext.UserMaster.AsNoTracking().FirstOrDefaultAsync(X => X.Username == Username && X.Active == true);
                return usermaster;
            }
            catch (Exception ex)
            {
                //Log.Error("Exception in UserMasterRepository", ex);
                throw ex;
            }
        }

        public async Task<UserMaster> Getuserwithusername(string Username)
        {
            try
            {
                var usermaster = await _Dbcontext.UserMaster.AsNoTracking().FirstOrDefaultAsync(X => X.Username == Username);
                return usermaster;
            }
            catch (Exception ex)
            {
                //Log.Error("Exception in UserMasterRepository", ex);
                throw ex;
            }
        }

        


        public UserMaster DeactivateUser(int userid)
        {
            try
            {
                var resuserMaster = _Dbcontext.UserMaster.AsNoTracking().FirstOrDefault(x => x.UserId == userid);
                if (resuserMaster != null)
                {
                    resuserMaster.Active = false;
                    resuserMaster.ModifyBy = 1;//Only admin can deactiv
                    resuserMaster.ModifyDate = DateTime.Now;
                    _Dbcontext.UserMaster.UpdateRange(resuserMaster);
                    _Dbcontext.SaveChanges();
                    return resuserMaster;

                }
                return null;
            }
            catch (Exception ex)
            {
                //Log.Error("Exception in UserMasterRepository", ex);
                throw ex;
            }
        }

    }
}
