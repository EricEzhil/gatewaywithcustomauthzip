﻿
using Microsoft.Extensions.Configuration;
using CoreLibrary;
using System;

namespace AuthenticationServer
{
    public class AuthService :IAuthService
    {
        private readonly IAuthRepository _authrepository;
        IConfiguration config;
        IConfigurationSection urls;
        private HttpCalls httpCalls;
        public AuthService(IAuthRepository authrepository, IConfiguration _config)
        {
            _authrepository = authrepository;
            config = _config;
            urls = config.GetSection("OtherApiUrls");

        }
       

        public object AuthenticateUser(LoginModel loginModel)
        {
            try
            {
                var user = GetUser(loginModel.Username);
                if (user == null) return "Invalid User";
                if (!user.Active) return "Inactive User";
                var Decryptpwd = EncryptionHelper.Decrypt(user.Password);
                TokenInformation tokenInformation = new TokenInformation() {UserId = user.UserId };
                if (loginModel.Password == Decryptpwd)
                {
                    TokenResponseObj responseObj = GetTokenInfo(loginModel.Username);//generate token
                    tokenInformation.Token = responseObj.token;
                    tokenInformation.Validto = responseObj.expiration;
                    tokenInformation.RoleId = user.RoleId;
                    _authrepository.SaveTokenInfo(tokenInformation);
                    return tokenInformation.Token;
                }
            }
            catch (Exception ex)
            {
                //Log.Error("Exception in AuthenticatePatient", ex);
                throw ex;
            }
            return null;
        }

        private TokenResponseObj GetTokenInfo(string username)
        {
            AuthenticationHelper authentication = new AuthenticationHelper(config);
            return authentication.GenerateKey(username);
        }

        public TokenInformation ValidateToken(string token)
        {
            var tokeninfo = _authrepository.GetTokenInfo(token);
            if (tokeninfo != null)
            {
                if (tokeninfo.Validto > DateTime.Now.AddMinutes(1))
                {
                    _authrepository.RefreshTokenInfo(tokeninfo);
                    tokeninfo.Token = string.Empty;
                    return tokeninfo;
                }
            }
            return null;
        }
        public bool RemoveTokenInfo(Logininfo userMaster)
        {
            if (_authrepository.RemoveTokenInfo(userMaster) > 0) return true;
            return false;
        }
              

        public UserMaster GetUser(string username)
        {
            try
            {
                httpCalls = new HttpCalls();
                string useriurl = urls["UserApi"].ToString() + "/GetUserbyusername?username=" + username;
                var obj = (GenericResponseObject<UserMaster>)httpCalls.HttpGetObj<GenericResponseObject<UserMaster>>(useriurl).Result;
                if (obj != null) return obj.data;
            }
            catch (Exception ex)
            {
              //  Log.Error("Exception in GetUser", ex);
            }
            return null;
        }

    }
}
