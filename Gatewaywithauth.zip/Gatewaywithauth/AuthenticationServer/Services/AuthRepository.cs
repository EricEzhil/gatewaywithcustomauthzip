﻿using Microsoft.EntityFrameworkCore;
using CoreLibrary;
using System;
using System.Linq;

namespace AuthenticationServer
{
    public class AuthRepository : IAuthRepository
    {
        private readonly TokenInformationContext _Dbcontext;

        public AuthRepository(TokenInformationContext dbcontext)
        {
            _Dbcontext = dbcontext;
        }
        public TokenInformation GetTokenInfo(string Token)
        {
            try
            {
                return _Dbcontext.TokenInformation.AsNoTracking().FirstOrDefault(x => x.Token == Token);
            }
            catch (Exception ex)
            {
               // Log.Error("Exception in AuthRepository", ex);
                throw ex;
            }

        }

        public bool SaveTokenInfo(TokenInformation token)
        {
            try
            {
                var rtoken = _Dbcontext.TokenInformation.AsNoTracking().FirstOrDefault(x => x.UserId == token.UserId && x.RoleId == token.RoleId);// check if token exists
                if (rtoken == null)
                {
                    token.Validto = DateTime.Now.AddMinutes(10);
                    _Dbcontext.TokenInformation.Add(token);
                    _Dbcontext.SaveChanges();
                }
                else
                {
                    rtoken.Token = token.Token; ///When new token created update validity & Token
                    rtoken.Validto = DateTime.Now.AddMinutes(10);
                    _Dbcontext.TokenInformation.UpdateRange(rtoken);
                    _Dbcontext.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                //Log.Error("Exception in AuthRepository", ex);
                throw ex;
            }
        }

        public bool RefreshTokenInfo(TokenInformation token)
        {
            try
            {
                var rtoken = _Dbcontext.TokenInformation.AsNoTracking().FirstOrDefault(x => x.TokenInformationID == token.TokenInformationID);
                if (rtoken != null)
                {
                    rtoken.Validto = DateTime.Now.AddMinutes(10);
                    _Dbcontext.TokenInformation.UpdateRange(rtoken);
                    _Dbcontext.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
               // Log.Error("Exception in AuthRepository", ex);
                throw ex;
            }
        }

        public int RemoveTokenInfo(Logininfo Logininfo)
        {
            var rtoken = _Dbcontext.TokenInformation.AsNoTracking().FirstOrDefault(x => x.UserId == Logininfo.userid && x.RoleId == Logininfo.roleid);
            if (rtoken != null)
            {
                _Dbcontext.TokenInformation.Remove(rtoken);
                return _Dbcontext.SaveChanges();
            }
            return 0;
        }
    }

}

