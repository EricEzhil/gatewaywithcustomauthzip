﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CoreLibrary;
namespace AuthenticationServer
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authservice;

        public AuthController(IAuthService authservice)
        {
            _authservice = authservice;

        }
        [HttpGet]
        public TokenInformation GetAccessKey()
        {
            try
            {
                Microsoft.Extensions.Primitives.StringValues authTokens;
                HttpContext.Request.Headers.TryGetValue("authToken", out authTokens);
                var _token = authTokens.FirstOrDefault();

                return _authservice.ValidateToken(_token);
            }
            catch (Exception)
            {
                return null;
            }
        }
       
        [HttpPost("UserLogin")]
        public object UserLogin(LoginModel loginModel)
        {
            try
            {
                var obj = _authservice.AuthenticateUser(loginModel);
                if (obj != null) return obj;
                else return "Invalid Credentials";
            }
            catch (Exception)
            {
                return "An exception has occured";
            }
        }
        [HttpPost("RemoveTokenInfo")]
        public void RemoveTokenInfo(Logininfo loginModel)
        {
            try
            {
                _authservice.RemoveTokenInfo(loginModel);

            }
            catch (Exception)
            {

            }


        }
    }
}
