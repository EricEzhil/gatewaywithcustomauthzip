﻿using CoreLibrary;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;
namespace AuthenticationServer
{
    [ExcludeFromCodeCoverage]
    public class TokenInformationContext : DbContext
    {
        public TokenInformationContext(DbContextOptions<TokenInformationContext> options) : base(options)
        {

        }
        public DbSet<TokenInformation> TokenInformation { get; set; }


    }
}
