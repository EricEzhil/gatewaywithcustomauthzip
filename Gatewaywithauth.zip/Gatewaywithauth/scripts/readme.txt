create 2 database with names AuthServer & UserMaster
update your connection string to the application